library(data.table)
#library("optimization")
#library("hydroGOF")

write_wofost_parfile<-function(config,outfile,spc=F){
  write("** auto generated config file",file=outfile)
  if (spc) sep<-" = " else sep<-"="
  for (i in 1:length(config)){
    #cat("i=",i,"\n")
    if (length(config[[i]])==1){
      if (class(config[[i]][[1]]) %in% c("numeric")){
        s<-sprintf("%s%s%.3f",names(config)[i],sep,config[[i]][[1]])
        write(s,file=outfile,append = T)
      } else if (class(config[[i]][[1]]) %in% c("integer")){
        s<-sprintf("%s%s%d",names(config)[i],sep,config[[i]][[1]])
        write(s,file=outfile,append = T)
      } else if (class(config[[i]][[1]]) %in% c("character")){
        s<-sprintf("%s%s'%s'",names(config)[i],sep,gsub("'","",config[[i]][[1]]))
        write(s,file=outfile,append = T)
      } 
    }
    else{
      s<-sprintf("%s=%s",names(config)[i],
                 paste(unlist(lapply(config[i],function(x)sprintf("%.4f",x))),collapse = ","))
      write(s,file=outfile,append = T)
      #write(
      #  paste(names(config)[i],"=",
      #        paste(
      #        unlist(
      #          lapply (1:length(config[[i]]$xvals),function(j){
      #              sprintf("%.3f,%.3f",as.numeric(config[[i]]$xvals[j]),as.numeric(config[[i]]$yvals[j]))
      #          })  
      #          ),collapse = ",")),file=outfile,append = T)
    } 
  }
}

flat_to_config<-function(config_flat){
  nm<-unique(gsub("([A-Z0-9])_\\d+","\\1",names(config_flat)))
  config<-lapply(nm,function(x){
    vals<-as.list(unlist(config_flat[names(config_flat)==x | grepl(paste0(x,"_"),names(config_flat))]))
    return (vals)
  })
  names(config)<-nm
  return(config)
}

flatlist <- function(mylist){
  config_flat<-lapply(rapply(mylist, enquote, how="unlist"), eval)
  names(config_flat)<-gsub("(\\d+)","_\\1",names(config_flat))
  names(config_flat)<-gsub("(TSUM)_(\\d)","\\1\\2",names(config_flat))
  names(config_flat)<-gsub("Q_10","Q10",names(config_flat))
  return(config_flat)
}


read_wofost_parfile<-function(filename){
  lines<-readLines(filename)
  lines<-gsub("(.*)!.*","\\1",lines)
  lines<-gsub(" +","",lines)
  lines<-lines[!grepl("\\*",lines) & lines!=""]
  lines<-gsub(" +","",lines)
  condensed<-paste(lines,collapse=";")
  condensed<-gsub(",;",",",condensed)
  expressions<-strsplit(condensed,";")

  config<-list()
  for (i in 1:length(expressions[[1]])){
    expr<-expressions[[1]][i]
    varname<-gsub("(.+)=.*","\\1",expr)
    RHS<-gsub(".+=(.*)","\\1",expr)
    if (substr(RHS,1,1) %in% c("\"","'")){
      config[[varname]]<-as.list(RHS)
      next
    } 
    spl<-strsplit(RHS,",")[[1]]
    if (length(spl)==1){
      if (grepl("\\.",RHS)) config[[varname]]<-as.list(as.numeric(RHS))
      else config[[varname]]<-as.list(as.integer(RHS))
    } else {
      #config[[varname]]<-list(xvals=spl[seq(1,length(spl),by=2)],
      #                        yvals=spl[seq(2,length(spl),by=2)])
      config[[varname]]<-as.list(as.numeric(spl[seq(1,length(spl),by=1)]))
    }
  }
  return (config)
}

run_wofost<-function(bindir=.GlobalEnv$bindir,bin=.GlobalEnv$bin) {
  oldwd<-getwd()
  setwd(bindir)
  system(bin,intern = T)  
  setwd(oldwd)
  read_wofost_output(file.path(outdir,outfile))
}

read_wofost_output<-function(filename){
  lines<-readLines(filename)
  lines<-lines[!grepl("no living leaves",lines)]
  starts<-which(grepl("===",lines))
  summarylines<-which(grepl("SUMMARY",lines))
  colnamelines<-which(grepl("YEAR  DAY",lines))
  colnames<-strsplit(lines[colnamelines]," +")
  colnames<-lapply(colnames,function(x)x[!x==""])
  headings<-lines[starts-1]
  nrows<-summarylines-starts-2
  filecontent<-paste(lines,collapse = "\n")
  outtables<-lapply(1:length(starts),function(i){
    return(suppressWarnings(
      fread(filecontent,skip = starts[i],nrows = nrows[i],col.names = colnames[[i]] )
    ))
  })
  outtables<-lapply(outtables,function(x){data.table(x,seasonstart=min(x$YEAR),seasonend=max(x$YEAR))})
  summaries<-lapply(1:length(summarylines),function(i){
    values<-as.numeric(unlist(strsplit(lines[summarylines[i]+2]," +",)))[-1]
    names(values)<-as.character(unlist(strsplit(lines[summarylines[i]+1]," +",)))[-1]
    return(values)
  })
  names(outtables)<-headings
  
  ##added later: rbind output of multiple years
  nm<-unique(names(outtables))
  details<-lapply(nm, function(n){
    rbindlist(outtables[names(outtables)==n])  
  })
  names(details)<-nm
  
  summaries<-lapply(1:length(names(outtables)),function(n){
    cbind(YEAR=max(outtables[[n]]$YEAR),data.table(t(summaries[[n]])))
  })
  names(summaries)<-names(outtables)
  
  sum<-lapply(nm, function(n){
    rbindlist(summaries[names(summaries)==n])  
  })
  names(sum)<-nm
  
  return(list(details=details,summaries=sum))
}


wrap_optim<-function(parameters){
  cat ("\n run ",.GlobalEnv$run)
  .GlobalEnv$run<-.GlobalEnv$run+1
  cat ("    parameters: ",paste(parameters))
  paridx<-which(names(config_min_flat) %in% change_pars)
  cfg<-config_flat
  for ( p in 1:length(parameters)){
    cl<-class(cfg[paridx][[1]])
    cfg[paridx[p]][[1]]<-parameters[p]
    class(cfg[paridx[p]][[1]])<-cl
  }
  cfg<-flat_to_config(cfg)
  write_wofost_parfile(cfg,file.path(workfile))
  run_wofost(bindir,bin)
  res<-read_wofost_output(file.path(outdir,outfile))
  val<-qualityfun(res)
  return (val)
}

set_wofost_runio<-function(file,key,value){
  cfg<-read_wofost_parfile(file)
  cfg[[key]]<-value
  write_wofost_parfile(cfg,file,spc = T)
}

read_weather_wofost<-function(file){
  lines<-readLines(file)
  start<-which(grepl("YEARNR",lines))
  year<-as.numeric(gsub(".*(\\d{4}).*","\\1",lines[start]))
  weather<-fread(file,skip = start+1)
  names(weather)<-c("statno","year","doy","rad","tmin","tmax","vp","wind","pr")
  ret<-list(weather)
  names(ret)<-year
  return(ret)
}

change_weather_wofost<-function(file,outfile=NA,col,shift=0,scale=1,newval=NA){
  lines<-readLines(file)
  start<-which(grepl("YEARNR",lines))
  header<-paste(lines[1:(start+1)],collapse="\n")
  year<-as.numeric(gsub(".*(\\d{4}).*","\\1",lines[start]))
  weather<-as.data.frame(fread(file,skip = start+1))
  names(weather)<-c("station_number","year","doy","radiation","tmin","tmax","vp","wind","pr")

  if (is.na(newval)) {
    for (c in 1:length(col)){
      weather[,col[c]]<-(weather[,col[c]]+shift[c])*scale[c]
    }
  } else {
    weather[,col]<-newval
  }
  
  content<-paste0(lapply(1:nrow(weather),function(i){
    sprintf(" %2d %4d %4d %7.1f %4.1f %4.1f %4.1f %4.1f %4.1f", 
            weather[weather$doy==i,]$station_number, 
            weather[weather$doy==i,]$year,
            weather[weather$doy==i,]$doy,
            weather[weather$doy==i,]$radiation,
            weather[weather$doy==i,]$tmin,
            weather[weather$doy==i,]$tmax,
            weather[weather$doy==i,]$vp,
            weather[weather$doy==i,]$wind,
            weather[weather$doy==i,]$pr)
  }),collapse = "\n")
  
  if (is.na(outfile)) outfile<-file
  
  write(header,file=outfile)
  write(content,file=outfile,append=T)
}


create_weather_wofost<-function(rawdata,lat,lon,angstr_a,angstr_b,altitude,shortname,longname,targetfolder,station_number=1){
  #lat=41.5
  #lon=0.5
  #angstr_a=-.25
  #angstr_b=-.50
  #altitude=190
  #station_number=1
  #shortname="SPAIN"
  header<-paste0("** WCCDESCRIPTION=",longname,"\n** WCCFORMAT=2\n** WCCYEARNR=")
  
  yearly<-split(rawdata,by="year")
  for ( i in 1:length(yearly)){
    df<-yearly[[i]]
    fn<-file.path(targetfolder,sprintf("%s%d.%s",shortname,station_number,substr(df$year[1],2,4)))
    cat(fn,"\n")
    content<-paste0(lapply(1:nrow(df),function(i){
      val<-unlist(df[doy==i])
      # paste0(station_number, 
      #        df[doy==i]$year,
      #        df[doy==i]$doy,
      #        df[doy==i]$radiation,
      #        df[doy==i]$tmin,
      #        df[doy==i]$tmax,
      #        df[doy==i]$vp,
      #        df[doy==i]$wind,
      #        df[doy==i]$pr)
      sprintf(" %2d %4d %4d %7.1f %4.1f %4.1f %4.1f %4.1f %4.1f", 
              station_number, 
              #val["year"],
              2001,
              val["doy"],
              val["radiation"],
              val["tmin"],
              val["tmax"],
              val["vp"],
              val["wind"],
              val["pr"])
      #sprintf(" %2d %4d %4d %7.1f %4.1f %4.1f %4.1f %4.1f %4.1f", 
      #        station_number, df[doy==i]$year,
      #        df[doy==i]$doy,
      #        df[doy==i]$radiation,
      #        df[doy==i]$tmin,
      #        df[doy==i]$tmax,
      #        df[doy==i]$vp,
      #        df[doy==i]$wind,
      #        df[doy==i]$pr)
    }),collapse = "\n")
    #write(paste0(header,df$year[1]),fn)
    write(paste0(header,2001),fn)
    write(sprintf(" %.2f %.2f %.2f %.2f %.2f",lon,lat,altitude,angstr_a,angstr_b),fn,append=T)
    write(content,fn,append = T)
  }
}
