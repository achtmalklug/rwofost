optim_saWofost<-function(parfiles,wofostbin=.GlobalEnv$wofostbin,wofostdir=.GlobalEnv$wofostdir,qualityfun=.GlobalEnv$qualityfun,start,lower,upper,control = list(nlimit=1,maxgood=1),maximization = T){
  .GlobalEnv$wofostbin<-wofostbin
  .GlobalEnv$parnames<-names(start)
  .GlobalEnv$wofostdir<-wofostdir
  .GlobalEnv$qualityfun<-qualityfun
  .GlobalEnv$parfiles<-parfiles
  .GlobalEnv$run<-0
  optim_sa(wrapWofostOptim,start = start,lower=lower,upper=upper,control=control,maximization = T)
}

start<-c(IDSOW=100)
lower<-c(IDSOW=10)
upper<-c(IDSOW=300)
wofostdir="/media/marian/3412E75E12E72398/CropM4RiskM_software/WOFOST Control Centre/"
qualityfun<-function(out)out$summaries$` POTENTIAL CROP PRODUCTION`$TWSO
#optim_saWofost(parfiles="RUNIO/WCCTI.TIM",start=start,upper=upper,lower=lower,wofostbin = "i:/CropM4RiskM_software/WOFOST Control Centre/wofost.exe")
undebug(wrapWofostOptim)
pars<-optim_saWofost(parfiles="RUNIO/WCCTI.TIM",start=start,upper=upper,lower=lower,wofostbin = "wine wofost.exe",wofostdir="/media/marian/3412E75E12E72398/CropM4RiskM_software/WOFOST Control Centre/",control = list(nlimit=1,maxgood=1),maximization = T)

wrapWofostOptim(parameters,wofostdir=wofostdir)
runWofost(wofostdir=wofostdir,wofostbin = wofostbin)

wofostbin<-"i:/CropM4RiskM_software/WOFOST Control Centre/wofost.exe"
out<-readWofostOutput("i:/CropM4RiskM_software/WOFOST Control Centre/OUTPUT/wcc.out")
qualityfun<-function(out)out$summaries$` POTENTIAL CROP PRODUCTION`$TWSO
qualityfun(out)
pars<-readWofostParfile("CROPD/BAR301.CAB")
pars$TSUM1<-
  writeWofostParfile(pars,"CROPD/test.cab")
wrapWofostOptim("CROPD/BAR301.CAB")

library(optimization)
parstrt<-c(TSUM1=800)
parmin<-c(TSUM1=600)
parmax<-c(TSUM2=1000)
optimization::optim_sa(wrapWofostOptim,start = parstrt,lower = parmin,upper=parmax)
